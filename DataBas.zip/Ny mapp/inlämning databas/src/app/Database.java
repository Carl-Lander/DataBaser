package app;

import tableclasses.Company;
import tableclasses.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Database {
    private Scanner scanner;
    Connection con = null;
    String url = "jdbc:sqlite:C:\\Users\\visio\\Desktop\\Ny mapp\\inlämning databas\\src\\holidaymaker12.db";

    public Database(){
        this.scanner = new Scanner(System.in);
        this.RunApp();
        this.getCustomer();
        this.connect();

    }

    public void RunApp(){
        int option;
        boolean keepAlive = true;
        while(keepAlive){
            System.out.println("\n|1| Create new costumer  |2| New booking  |3| Find Customer");
            System.out.println(": ");
            option = Integer.parseInt(scanner.nextLine());
            switch (option){
                case 1:
                    //createCustomer();
                    connect();
                    break;
                case 2:
                    //createBooking();
                case 3:
                    getCustomer();
            }
        }
    }

    public void connect() {
        try {
            con = DriverManager.getConnection(url);
            System.out.println(" Hotel Database Connected..\n --------");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public int createCompany(String companyName) {
        int createID1 = 0;
        String query = "INSERT INTO Company(Company_Name) VALUES(?)";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, companyName);
            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();
            while (keys.next()) {
                createID1 = keys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return createID1;
    }

    public void viewAmeneties(int hotelID) {
        String query = "SELECT Amenity_Info.Amenity_ID, Hotel.Hotel_ID, Hotel.Hotel_Name, Description FROM Amenity_Info\n" +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Aminity.Hotel_ID\n" +
                "INNER JOIN Amenity ON Amenity.Amenity_ID = Amenity_Info.Amenity_ID\n" +
                "WHERE Hotel.Hotel_ID = '" + hotelID + "'\n" +
                "GROUP BY Amenity_Info.Description ";
        try {
            Statement statement = con.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("Hotel ID    Hotel Name    Amenity ID    Description");
            while (resultSet.next()) {
                String title = resultSet.getString("Hotel_Name");
                int amenityID = resultSet.getInt("Amenity_ID");
                String description = resultSet.getString("Description");
                System.out.println(hotelID + "          " + title + "         " + amenityID + "        " + description);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public int createCustomer(int companyID, String firstName, String lastName, String adress,
                             String city, String country, String phoneNumber, String email,
                             String birthday) {
        int customerID = 0;
        String query = "INSERT INTO Customer(First_Name, Last_Name, Adress, City, Country, PhoneNumber, Email, Birthday, Company_ID" +
                "VALUES (?,?,?,?,?,?,?,?,?);";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, adress);
            statement.setString(4, city);
            statement.setString(5, country);
            statement.setString(6, phoneNumber);
            statement.setString(7, email);
            statement.setString(8, birthday);
            statement.setInt(9, companyID);

            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();
            while (keys.next()) {
                customerID = keys.getInt(1);
            }
            System.out.println("[Customer ADDED!]. Customer ID: " + customerID + " .Customer name: " + firstName + " " + lastName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return customerID;
    }

    public ArrayList<Company> getCompany() {
        ArrayList<Company> companies = new ArrayList<>();
        String query = "SELECT * FROM Company";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("Company_ID");
                String name = resultSet.getString("Company_Name");
                companies.add(new Company(id, name));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return companies;
    }

    public boolean findAvailableRoom(int roomSize, String checkInDate, int hotelID, String checkOutDate) {
        boolean isEmpty = true;
        String query = "SELECT Room.Room_ID,Room.Room_Name,Room.Room_Size,Hotel.Hotel_ID,Hotel.Hotel_Name," +
                "Hotel.City,Hotel.Country,Room.Price FROM Room\n" +
                "LEFT JOIN Calendar ON Room.Room_ID = Calendar.Room_ID\n" +
                "INNER JOIN Hotel ON Hotel.Hotel_ID = Room.Hotel_ID\n" +
                "WHERE Room.Room_Size = ? AND Hotel.Hotel_ID = ? AND Calendar.CheckOut_Date <= ?\n" +
                "OR Room.Room_Size = ? AND Hotel.Hotel_ID = ? AND Calendar.CheckIn_Date >= ?\n" +
                "OR Room.Room_Size = ? AND Hotel.Hotel_ID = ? AND Calendar.Calendar_ID IS NULL\n" +
                "GROUP BY Room.Room_ID ORDER BY Hotel.Hotel_ID";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, roomSize);
            statement.setInt(2, hotelID);
            statement.setString(3, checkOutDate);
            statement.setInt(4, roomSize);
            statement.setInt(5, hotelID);
            statement.setString(6, checkInDate);
            statement.setInt(7, roomSize);
            statement.setInt(8, hotelID);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                System.out.println("RoomID    RoomName   RoomSize   HotelID   HotelName   City   Country   Price");
                isEmpty = false;
                int roomID = resultSet.getInt("Room_ID");
                String roomName = resultSet.getString("Room_Name");
                int roomSize1 = resultSet.getInt("Room_Size");
                String hotelID1 = resultSet.getString("Hotel_ID");
                String hotelName = resultSet.getString("Hotel_Name");
                String city = resultSet.getString("City");
                String country = resultSet.getString("Country");
                int price = resultSet.getInt("Price");
                System.out.println(roomID + "     " + roomName + "     " + roomSize1 + "     " + hotelID1 + "     " + hotelName + "    " +
                        city + "      " + country + "      " + price);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        if (isEmpty) {
            System.out.println("There are no room available.. ");
            return false;
        }
        return true;
    }

    public int createBooking(int customerID, int calendarID) {
        int bookingID = 0;
        String query = "INSERT INTO Booking(Customer_ID,Calendar_ID) VALUES(?,?)";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, customerID);
            statement.setInt(2, calendarID);
            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();

            while (keys.next()) {
                bookingID = keys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bookingID;
    }

    public int creatCalendar(String checkInDate, String checkOutDate, int roomID) {
        int calendarID = 0;
        String query = "INSERT INTO Calendar(CheckIn_Date,CheckOut_Date,Room_ID) VALUES(?,?)";

        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, checkInDate);
            statement.setString(2, checkOutDate);
            statement.setInt(3, roomID);

            statement.executeUpdate();
            ResultSet keys = statement.getGeneratedKeys();

            while (keys.next()) {
                calendarID = keys.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return calendarID;
    }

    public ArrayList<Customer> getCustomer() {
        ArrayList<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";

        try {
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int customerID = resultSet.getInt("Customer_ID");
                String firstName = resultSet.getString("First_Name");
                String lastName = resultSet.getString("Last_Name");
                String adress = resultSet.getString("Adress");
                String city = resultSet.getString("City");
                String country = resultSet.getString("Country");
                String phoneNumber = resultSet.getString("Phone_Number");
                String email = resultSet.getString("Email");
                String birthDate = resultSet.getString("Birth_Date");
                int companyID = resultSet.getInt("Company_ID");
                customers.add(new Customer(customerID, firstName, lastName, adress, city, country, phoneNumber, email, birthDate, companyID));

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return customers;
    }
}









