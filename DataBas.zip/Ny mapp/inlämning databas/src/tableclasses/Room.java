package tableclasses;

public class Room {
    public int roomID;
    public int roomNumber;
    public int roomSize;
    public int hotelID;
    public int price;

    public Room(int roomID,int roomNumber,int roomSize,int hotelID,int price){
        this.roomID = roomID;
        this.roomNumber = roomNumber;
        this.roomSize = roomSize;
        this.hotelID = hotelID;
        this.price = price;
    }

}
